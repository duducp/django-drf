# Create your view here.
# https://www.django-rest-framework.org/api-guide/viewsets/#genericviewset
