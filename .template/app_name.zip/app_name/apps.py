from django.apps import AppConfig


class {{camel_case_app_name}}Config(AppConfig):
    name = 'project.{{app_name}}'
    verbose_name = '{{camel_case_app_name}}'
