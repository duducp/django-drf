Hi, you just created an app with the name {{camel_case_app_name}}

The first step is to create your database model in "project/{{app_name}}/models.py".

The next step is for you to register it so Django can detect your models.
To do this, go to "project/core/settings/base.py" and add the following line in LOCAL_APPS:
```
'project.{{app_name}}.apps.{{camel_case_app_name}}Config',
```

After configuring your model you must create the view, serializer and register the application's urls.

Finally, you must register the app's URL in "project/urls.py" by adding the following line:
```
path('{{app_name}}/', include('project.{{app_name}}.urls')),
```
